module.exports = {
  REQUEST: "request",
  ONGOING: "ongoing",
  COMPLETED: "completed",
  CANCELED: "canceled",
};
