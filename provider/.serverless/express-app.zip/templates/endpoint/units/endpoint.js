module.exports = async () => {
  return "Newly created endpoint";
};
