module.exports = [
  { topic: "dev_topic", partition: 0 },
  { topic: "dev_topic_2", partition: 0 },
  { topic: "requests", partition: 0 },
  { topic: "acceptedRides", partition: 0 },
];
