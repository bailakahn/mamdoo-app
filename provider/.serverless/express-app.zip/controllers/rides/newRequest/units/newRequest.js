module.exports = async () => {
  return { success: true };
};
